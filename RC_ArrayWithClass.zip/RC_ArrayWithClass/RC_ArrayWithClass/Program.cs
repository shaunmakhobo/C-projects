﻿using System.Security.Cryptography.X509Certificates;

namespace RC_ArrayWithClass
{
    internal class Program
    {
       public static void Main(string[] args)
        {
            int size;
            Console.Write("Enter number of people: ");
            size = Convert.ToInt32(Console.ReadLine());

            Person[] person = new Person[size];

            EnterDetails(person);
           
        }
        public static void EnterDetails(Person[] person)
        {
            for (int i = 0; i < person.Length; i++)
            {
                person[i] = new Person();

                Console.Write($"Enter name of person {i + 1} :");
                person[i].Name = Console.ReadLine();
                Console.Write($"Enter age of person {i + 1} :");
                person[i].Age = Convert.ToInt32(Console.ReadLine());
            }
            foreach (var i in person)
            {
                Console.WriteLine("{0} is {1}", i.Name, i.Age);
            }

            Console.ReadKey();
        }
    }
}
