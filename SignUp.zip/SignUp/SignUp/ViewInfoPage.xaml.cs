﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SignUp
{
    /// <summary>
    /// Interaction logic for ViewInfoPage.xaml
    /// </summary>
    public partial class ViewInfoPage : Page
    {
        public ViewInfoPage()
        {
            InitializeComponent();

            // Set the TextBlock values from the stored user inputs
            NameTextBlock.Text = $"Name: {MainWindow.Name}";
            ageTextBlock.Text = $"Age: {MainWindow.Age}";
            studentNumTextBlock.Text = $"studentNumber: {MainWindow.studentNum}";
            emailTextBlock.Text = $"Email: {MainWindow.studentEmail}";
            courseTextBlock.Text = $"Course: {MainWindow.Course}";
            campusTextBlock.Text = $"Campus: {MainWindow.Campus}";
            FileTextBlock.Text = $"Selected File: {MainWindow.SelectedFile ?? "No file selected"}";

        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Window.GetWindow(this)?.Close();  // Close the current window
        }
    }
}
