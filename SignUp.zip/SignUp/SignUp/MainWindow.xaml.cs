﻿using Microsoft.Win32;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SignUp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static string Name { get; private set; }
        public static int Age { get; private set; }
        public static string studentNum { get; private set; }
        public static string studentEmail { get; private set; }
        public static string Course { get; private set; }
        public static string Campus { get; private set; }

        public static string SelectedFile { get; private set; }
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            Name = txtName.Text;
            Age = Convert.ToInt32(txtAge.Text);
            studentNum = txtStudNo.Text;
            studentEmail = txtStudemail.Text;
            Course = txtCourse.Text;
            Campus = txtCampus.Text;

            //Data Validation
            if (string.IsNullOrWhiteSpace(Name) ||
                int.IsNegative(Age) ||
                string.IsNullOrWhiteSpace(studentNum) ||
                string.IsNullOrWhiteSpace(studentEmail) ||
                string.IsNullOrWhiteSpace(Course) ||
                string.IsNullOrWhiteSpace(Campus))
            {
                FeedbackTextBlock.Text = "Please enter all Fields.";
                FeedbackTextBlock.Foreground = System.Windows.Media.Brushes.Red;
                return;
            }

            FeedbackTextBlock.Text = $"Hello, {Name}! Your details have been submitted.";
            FeedbackTextBlock.Foreground = System.Windows.Media.Brushes.Green;

        }

        private void btnUpload_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog()
            {
                Title = "Select a File",
                Filter = "All Files (*.*)|*.*" // Allows selecting any file
            };
            
            bool? result = openFileDialog.ShowDialog();
            if (result == true)
            {
                SelectedFile = openFileDialog.FileName;
                FeedbackTextBlock.Text = $"Selected File: {SelectedFile}";

                FeedbackTextBlock.Foreground = System.Windows.Media.Brushes.Black;
            }
            else
            {
                FeedbackTextBlock.Text = "No file selected.";
                FeedbackTextBlock.Foreground = System.Windows.Media.Brushes.Gray;
            }
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {

            // Navigate to ViewInfoPage
            ViewInfoPage viewPage = new ViewInfoPage();
            NavigationWindow navWindow = new NavigationWindow
            {
                Content = viewPage
            };
            navWindow.Show();
            this.Close();  // Close the main window
        }
    }
}