﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace POE_Final
{
    /// <summary>
    /// Interaction logic for CaloriesWindow.xaml
    /// </summary>
    public partial class CaloriesWindow : Window
    {
       public List<Recipe> RecipesDentical = new List<Recipe>();
        public CaloriesWindow()
        {
            InitializeComponent();
            ButtonAdd.Click += ButtonAdd_Click;
            ButtonClear.Click += ButtonClear_Click;
        }

        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            int calories1 = int.Parse(TextBoxCalorie1.Text);
            int calories2 = int.Parse(TextBoxCalorie2.Text);

            int tot = calories1 + calories2;

            TextBoxTotal.Text = tot.ToString();

            if (tot > 300)
            {
                MessageBox.Show("Your calories exceeded 300!!!!");
            }
            else
            {
                MessageBox.Show("Total Calories:" + tot);
            }

        }

        private void ButtonMinus_Click(object sender, RoutedEventArgs e)
        {
            int calories1 = int.Parse(TextBoxCalorie1.Text);
            int calories2 = int.Parse(TextBoxCalorie2.Text);

            int tot = calories1 - calories2;

            TextBoxTotal.Text = tot.ToString();


            if (tot > 300)
            {
                MessageBox.Show("Your calories exceeded 300!!!!");
            }
            else
            {
                MessageBox.Show("Total Calories:" + tot);
            }
        }

        private void ButtonSub_Click(object sender, RoutedEventArgs e)
        {
            int calories1 = int.Parse(TextBoxCalorie1.Text);
            int calories2 = int.Parse(TextBoxCalorie2.Text);

            int tot = calories1 * calories2;

            TextBoxTotal.Text = tot.ToString();


            if (tot > 300)
            {
                MessageBox.Show("Your calories exceeded 300!!!!");
            }
            else
            {
                MessageBox.Show("Total Calories:" + tot);
            }
        }

        private void ButtonDiv_Click(object sender, RoutedEventArgs e)
        {
            int calories1 = int.Parse(TextBoxCalorie1.Text);
            int calories2 = int.Parse(TextBoxCalorie2.Text);

            int tot = calories1 / calories2;

            TextBoxTotal.Text = tot.ToString();


            if (tot > 300)
            {
                MessageBox.Show("Your calories exceeded 300!!!!");
            }
            else
            {
                MessageBox.Show("Total Calories:" + tot);
            }

        }

        private void ButtonClear_Click(object sender, RoutedEventArgs e)
        {
            TextBoxCalorie1.Text = "";
            TextBoxCalorie2.Text = "";
            TextBoxTotal.Text = "";
            TextBoxCalorie1.Focus();
        }
    }
}
