﻿namespace Year
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Declaration
            int currentYear;
            int yearOfBirth;
            int age;
            String name;

            //Prompting the user
            try
            {
                Console.Write("Please type your name: ");
                name = Console.ReadLine();
                Console.Write("Please Enter current year: ");
                currentYear = Convert.ToInt32(Console.ReadLine());
                Console.Write("Please Enter your year of Birth: ");
                yearOfBirth = Convert.ToInt32(Console.ReadLine());

                //Calculating User's Age in current year
                age = currentYear - yearOfBirth;
                Console.WriteLine($"{name} you will be {age} in the year {currentYear}");
            } catch (Exception e)
            {
                Console.WriteLine("Year should be in numbers and can only be an integer and don't forget your name is a string");
            }
            Console.ReadKey();

        }
    }
}
