﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RC_GabbageCollector
{
    internal class Program
    {
        static void Main(string[] args)
        {
            object[] objects = new object[1000];

            for (int i = 0; i < object.Length; i++)
            {
                objects[i] = new object();
            }

        }
    }
}
