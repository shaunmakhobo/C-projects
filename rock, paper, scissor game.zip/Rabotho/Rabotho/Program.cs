﻿namespace Rabotho
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Declaration
            bool playAgain = true;
            Random random = new Random();
            String response;
            int Number;
           
            String guess;
            String computer; 

            while (playAgain)
            {

                Number = random.Next(1, 4);
                response = "";
                
                guess = "";
                computer = "";

                

                while (guess != "ROCK" && guess != "PAPER" && guess != "SCISSORS")
                {
                    Console.Write("Please Enter (ROCK, PAPER or SCISSORS) : ");
                    guess = Console.ReadLine();
                    guess = guess.ToUpper();
                   
                }
              
                switch (Number)
                {
                    case 1:
                        computer = "ROCK";
                        Console.WriteLine($"Computer chose: {computer}");
                        break;
                    case 2:
                        computer = "PAPER";
                        Console.WriteLine($"Computer chose: {computer}");
                        break;
                    case 3:
                        computer = "SCISSORS";
                        Console.WriteLine($"Computer chose: {computer}");
                        break;
                }
                switch(guess)
                {
                    case "ROCK":
                        if (computer == "ROCK")
                        {
                            Console.WriteLine("Draw !!!");
                        }
                        else if (computer == "PAPER")
                        {
                            Console.WriteLine("You lose !");
                        }
                        else if(computer == "SCISSORS")
                        {
                            Console.WriteLine("You win !!");
                        }
                        break;
                    case "PAPER":
                        if (computer == "ROCK")
                        {
                            Console.WriteLine("You win !!");
                        }
                        else if (computer == "PAPER")
                        {
                            Console.WriteLine("Draw !!!");
                        }
                        else if (computer == "SCISSORS")
                        {
                            Console.WriteLine("You lose !");
                        }
                        break;
                    case "SCISSORS":
                        if (computer == "ROCK")
                        {
                            Console.WriteLine("You lose !");
                        }
                        else if (computer == "PAPER")
                        {
                            Console.WriteLine("You win !!");
                        }
                        else if (computer == "SCISSORS")
                        {
                            Console.WriteLine("Draw !!!");
                        }
                        break;
                
                }
                Console.Write("Would you like to play again? (Y/N):");
                response = Console.ReadLine();
                response = response.ToUpper();

                if (response == "Y")
                {
                    playAgain = true;
                }
                else 
                {
                    playAgain = false;
                }
                

            }
            Console.WriteLine("Thank you for playing");

            Console.ReadKey();
        }
    }
}
