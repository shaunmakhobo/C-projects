﻿namespace iceTask2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Declaration 
            double score;
            double testTotal;
            double percentage;
            String results;

            //Calling Methods and using catche Exception to handle errors
            try
            {
                //Prompting user 
                Console.Write("Please Enter the score: ");
                score = Convert.ToDouble(Console.ReadLine());
                Console.Write("Please Enter Test total: ");
                testTotal = Convert.ToDouble(Console.ReadLine());

                //checking user's input 
                if (score < 0 || testTotal < 0)
                {
                    throw new ArithmeticException("Score cannot be negative and total amount cannot be also negative");
                }
                else if (score > testTotal)
                {
                    throw new ArithmeticException("score cannot be greater than test total");
                }

                //Calling methods that calculate percentage and displaying result
                percentage = CalcPercentage(score, testTotal);
                results = Qualification(percentage, testTotal, score);

                //Output After Calculation
                Console.WriteLine($"You have obtained a percentage of {percentage}%");
                Console.WriteLine($"You got a {results}");
                
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
        
        
            Console.ReadKey();
        }
        public static double CalcPercentage(double score, double testTotal)
        {
            //Declarations
            double percentage;

            //Calculate the test percentage
            percentage = (score / testTotal) * 100;
            percentage = Math.Round(percentage);

            return percentage;
        }
        public static String Qualification(double percentage, double testTotal, double score)
        {
            //Declaration
            String result = "";
            String archievement1 = "Fail";
            String archievement2 = "Pass";
            String archievement3 = "Pass Distinction";

            //Comparing the percentages and determining archivement
            if(percentage < 50 && percentage >= 0)
            {
              result = archievement1;
                
            }
            else if (percentage >= 50 && percentage < 80)
            {
                result = archievement2;
                
            }
            else if(percentage >= 80 &&  percentage <= 100)
            {
                result = archievement3;
                
            }
           
            return result;

        }
    }
}
