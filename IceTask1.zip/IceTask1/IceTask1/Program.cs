﻿namespace IceTask1
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Declaration
            const double priceOfTicket = 200;
            String name;
            int numberOfTickets;
            double amountToPay;

            //Prompting the user
            Console.Write("Please Enter your name: ");
            name = Console.ReadLine();
            Console.Write("Please Enter number of Tickets you would like to purchase: ");
            numberOfTickets = Convert.ToInt32(Console.ReadLine());

            //Calculate amount to be paid
            amountToPay = numberOfTickets * priceOfTicket;

            //Diplaying results 
            Console.WriteLine("{0} you need to pay {1:c}", name, amountToPay);

            Console.ReadKey();
        }
    }
}
