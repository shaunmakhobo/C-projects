﻿namespace voidMethod
{
    public class Program
    {
       public static void Main(string[] args)
        {
            // Declaration
            int number1;
            int number2;

           // int sum, difference, product, remainder, quotient;

            //input
            Console.Write("Please Enter your first number: ");
            number1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Please Enter your second number: ");
            number2 = Convert.ToInt32(Console.ReadLine());

           

            //Calling Sum method
            CalcSum(number1, number2);

            //Calling Difference Method
            CalcDifference(number1, number2);

            //Calling Product Method
            CalcProduct(number1, number2);

            //Calling Quotient Method
            CalcQuotient(number1, number2);

            //Calling Remainder Method
            CalcRemainder(number1, number2);

            Console.ReadKey();
        }
     public static void CalcSum(int num1, int num2)
        {
            int sum;
            sum = num1 + num2;
            Console.WriteLine(" sum = {0}", sum);
            
        }
        public static void CalcDifference(int num1, int num2)
        {
            //Declare
            int difference;

            //Calculate Difference
            difference = num1 - num2;

            //Output
            Console.WriteLine("{0} - {1} = {2}", num1, num2, difference);
        }
        public static void CalcProduct(int num1, int num2)
        {
            //Declare
            int product;

            //Calculate product
            product = num1 * num2;

            //Output
            Console.WriteLine("{0} * {1} = {2}", num1, num2, product);
        }
        public static void CalcQuotient(int num1, int num2)
        {
            //Declare
            double quotient;

            //Calculate quotient
            quotient = (double) num1 / num2;

            //Output
            Console.WriteLine("{0} / {1} = {2:n2}", num1, num2, quotient);
        }
        public static void CalcRemainder(int num1, int num2)
        {
            //Declare
            int Remainder;

            //Calculate Remainder
            Remainder = num1 % num2;

            //Output
            Console.WriteLine("The remainder is = {0}", Remainder);
        }

    }
}
