using Part_2;

namespace TestUnit
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Ingredients ingredients = new Ingredients();

            ingredients.setCalories = 65;
            ingredients.setCalories = 10;
            ingredients.setCalories = 200;
            ingredients.setCalories = 190;
            ingredients.setCalories = 280;

            double total = ingredients.CalcSize();

            Assert.AreEqual(745.0 ,total);
        }
    }
}