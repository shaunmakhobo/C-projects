﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Part_2
{
    public class Ingredients
    {
        private string step;
        private string ingreients;
        private string recipe;
        private double calories;
        private double scaleFactor = 1;
        private string food;
        private double size;

        //These arrays will be used to store values to save the ingredients.
        private List<string> ingredients = new List<string>();
        private List<double> quantityIngredients = new List<double>();
        private List<double> calory = new List<double>();
        private List<string> unitMeasures = new List<string>();
        private List<string> steps = new List<string>();
        private List<string> foodGroup = new List<string>();


        /*
         The private fields will be saved using the and set methods
         */
        public string setFood
        {
            set { food = value; }
        }

        public double setCalories
        {
            set { calories = value;}
        }
        public string setRecipe
        {
            set { recipe = value; }
        }
        public string setIngreients
        {
            set { ingredients.Add(value); }
        }

        public double setSizeIngredients
        {
            set { quantityIngredients.Add(value); }
        }

        public string setUnitMeasures
        {
            set { unitMeasures.Add(value); }
        }
        public double setScaleFactor
        {
            set { scaleFactor = value; }
        }
        public string setSteps
        {
            set { steps.Add(value); }
        }
        //And the fields will be retreived using the get method
        public string getRecipe
        {
            get { return recipe; }
        }

        public List<string> getFoodGroup
        {
            get { return foodGroup; }
        }

        public List<double> getCalories
        {
            get { return calory; }
        }
        public List<string> getIngreients
        {
            get { return ingredients; }
        }

        public List<double> getSizeIngredients
        {
            get { return quantityIngredients; }
        }

        public List<string> getUnitMeasures
        {
            get { return unitMeasures; }
        }
        public double getScaleFactor
        {
            get { return scaleFactor; }
        }

        public List<string> getSteps
        {
            get { return steps; }
        }

        public double getSize
        {
            get { return size; }
        } 

        public double CalcSize()
        {
            for(int i = 0; i< calory.Count; i++)
            {
                size   += calory[i];
                if(size > 300)
                {
                    Console.WriteLine("Calories exceeded 300!!!");
                }
            }
            return size;

        }
     
    }
}

