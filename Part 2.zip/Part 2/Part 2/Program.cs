﻿using System.Xml.Linq;

namespace Part_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double quantOfIngredients;
            string aRecipe;
            string recipeSteps;
            string unitMeasure;
            int numberOfIngre;
            int numberOfSteps;
            int MenuOption = 0;
            int ScaleMenu = 0;
            int DeleteMenu = 0;
            int scale;
            bool exit = true;
            string Enter;
            int numRecipe = 0;
            double scaleFact = 1;
            List<string> nameRecipe = new List<string>();

            List<Ingredients> recepies = new List<Ingredients>();


            List<string> ingredients;
            List<double> quantityIngredients;
            List<string> unitMeasures;
            List<string> steps;


            while (exit)
            {
                //This will prompt the user to enter an option for what the recipe program
                Console.WriteLine("Enter which option you want");
                Console.WriteLine("1) Add new recipe");
                Console.WriteLine("2) Display all recipes");
                Console.WriteLine("3) Scale Factor");
                Console.WriteLine("4) Clear a recipe");
                Console.WriteLine("5) Exit");
                Enter = Console.ReadLine();

                //This is to check if the user inputs a digit
                while (true)
                {
                    if (int.TryParse(Enter, out MenuOption))
                    {
                        MenuOption = Convert.ToInt32(Enter);
                        if (MenuOption > 0)
                        {
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Invalid input! ENTER A DIGIT!!");
                            Console.Write("Enter option: ");
                            Enter = Console.ReadLine();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input! ENTER A DIGIT!!");
                        Console.Write("Enter option: ");
                        Enter = Console.ReadLine();

                    }
                }
                Console.WriteLine();

                switch (MenuOption)
                {
                    //This case adds a new recipe
                    case 1:
                        //The object array will store the recipes
                        double calory = 0;
                        recepies.Add(new Ingredients());
                        while (numRecipe < recepies.Count)
                        {
                            ingredients = recepies[numRecipe].getIngreients;
                            quantityIngredients = recepies[numRecipe].getSizeIngredients;
                            unitMeasures = recepies[numRecipe].getUnitMeasures;
                            steps = recepies[numRecipe].getSteps;

                            Console.Write($"Enter the name of the Recipe: ");
                            recepies[numRecipe].setRecipe = Console.ReadLine();
                            Console.WriteLine();

                            nameRecipe.Add(recepies[numRecipe].getRecipe);

                            //User will enter the number of the ingredients
                            Console.Write("Enter number of ingredients: ");
                            Enter = Console.ReadLine();

                            //This is to check if the user inputs a digit
                            while (true)
                            {
                                if (int.TryParse(Enter, out numberOfIngre))
                                {
                                    numberOfIngre = Convert.ToInt32(Enter);
                                    if (numberOfIngre > 0)
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid input! ENTER A DIGIT");
                                        Console.Write("Enter option: ");
                                        Enter = Console.ReadLine();
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Invalid input! ENTER A DIGIT!!");
                                    Console.Write("Enter number of ingredients: ");
                                    Enter = Console.ReadLine();
                                }
                            }

                            //User will enter the details of the ingredients
                            for (int i = 0; i < numberOfIngre; ++i)
                            {
                                Console.Write($"Enter ingredient {(i + 1)}: ");
                                recepies[numRecipe].setIngreients = Console.ReadLine();

                                Console.Write($"Enter quantity {(i + 1)}: ");
                                Enter = Console.ReadLine();
                                while (true)
                                {
                                    if (double.TryParse(Enter, out quantOfIngredients))
                                    {
                                        quantOfIngredients = Convert.ToDouble(Enter);
                                        if (quantOfIngredients > 0)
                                        {
                                            break;
                                        }
                                        else
                                        {
                                            Console.WriteLine("Invalid input! ENTER A DIGIT!!");
                                            Console.Write("Enter option: ");
                                            Enter = Console.ReadLine();
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid input! ENTER A DIGIT!!");
                                        Console.Write($"Enter quantity {(i + 1)}: ");
                                        Enter = Console.ReadLine();
                                    }
                                }
                                recepies[numRecipe].setSizeIngredients = quantOfIngredients;

                                Console.Write($"Enter unit of measure {(i + 1)}: ");
                                recepies[numRecipe].setUnitMeasures = Console.ReadLine();

                                Console.WriteLine();

                                Console.WriteLine("Enter mumber of calories: ");
                                recepies[numRecipe].setCalories = Convert.ToDouble(Console.ReadLine());


                                calory = recepies[numRecipe].CalcSize();

                              

                                Console.WriteLine("Enter food group: ");
                                recepies[numRecipe].setFood = Console.ReadLine();
                            }

                            //User will enter the number of the steps
                            Console.Write("Enter number of steps: ");
                            Enter = Console.ReadLine();

                            //This is to check if the user inputs a digit
                            while (true)
                            {
                                if (int.TryParse(Enter, out numberOfSteps))
                                {
                                    numberOfSteps = Convert.ToInt32(Enter);
                                    if (numberOfSteps > 0)
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid input! ENTER A DIGIT!!");
                                        Console.Write("Enter option: ");
                                        Enter = Console.ReadLine();
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Invalid input! ENTER A DIGIT!!");
                                    Console.Write("Enter number of steps: ");
                                    Enter = Console.ReadLine();
                                }
                            }

                            //This is where the user enters the description of the steps
                            for (int i = 0; i < numberOfSteps; ++i)
                            {
                                Console.Write($"Enter step {(i + 1)}: ");
                                recepies[numRecipe].setSteps = Console.ReadLine();
                            }

                            //This function will display the recipe's ingredients and steps after the recipes have been added
                            Console.WriteLine("-----------------------------------------------------------------------");
                            Console.WriteLine(recepies[numRecipe].getRecipe);
                            Console.WriteLine("-----------------------------------------------------------------------");

                            Console.WriteLine("Ingredients: ");
                            for (int j = 0; j < ingredients.Count; j++)
                            {
                                Console.WriteLine($"- {quantityIngredients[j] * recepies[numRecipe].getScaleFactor} {unitMeasures[j]} of {ingredients[j]}");
                            }
                            Console.WriteLine("Steps: ");
                            for (int j = 0; j < steps.Count; j++)
                            {
                                Console.WriteLine($"{(j + 1)}){steps[j]}");
                            }

                            Console.WriteLine("");
                            Console.WriteLine($"Total calories is = {calory}");

                            ++numRecipe;
                        }
                        break;

                    //This case displays all the recipes
                    case 2:

                        if (!(recepies.Count == 0))
                        {
                            foreach (string sort in nameRecipe)
                            {
                                for (int i = 0; i < recepies.Count; i++)
                                {

                                    ingredients = recepies[i].getIngreients;
                                    quantityIngredients = recepies[i].getSizeIngredients;
                                    unitMeasures = recepies[i].getUnitMeasures;
                                    steps = recepies[i].getSteps;
                                
                                    nameRecipe.Sort();


                                    if (sort == recepies[i].getRecipe)
                                    {
                                        //Displaying the recipe's ingredients and steps based on which recipe the user chooses
                                        Console.WriteLine("-----------------------------------------------------------------------");
                                        Console.WriteLine(recepies[i].getRecipe);
                                        Console.WriteLine("-----------------------------------------------------------------------");

                                        Console.WriteLine("Ingredients: ");
                                        for (int j = 0; j < ingredients.Count; j++)
                                        {
                                            Console.WriteLine($"- {quantityIngredients[j] * recepies[i].getScaleFactor} {unitMeasures[j]} of {ingredients[j]}");
                                        }

                                        Console.WriteLine("Steps: ");
                                        for (int j = 0; j < steps.Count; j++)
                                        {
                                            Console.WriteLine($"{(j + 1)}){steps[j]}");
                                        }

                                        Console.WriteLine("");
                                    }

                                        
                                }
                            }
                        }
                        else
                        {
                            Console.WriteLine("There is no existing recipe");
                        }
                        Console.WriteLine();
                        break;

                    //This case will change the scale factor of the ingredients
                    case 3:
                        if (!(recepies.Count == 0))
                        {
                            Console.WriteLine("Which recipe would you like to Scale: ");

                            for (int j = 0; j < recepies.Count; j++)
                            {
                                Console.WriteLine($"{(j + 1)}){recepies[j].getRecipe}");
                            }
                            Console.Write("Enter option: ");
                            Enter = Console.ReadLine();

                            //This is to check if the user inputs a digit
                            while (true)
                            {
                                if (int.TryParse(Enter, out ScaleMenu))
                                {
                                    ScaleMenu = Convert.ToInt32(Enter);
                                    if (ScaleMenu > 0)
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid input! ENTER A DIGIT!!");
                                        Console.Write("Enter option: ");
                                        Enter = Console.ReadLine();
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Invalid input! ENTER A DIGIT!!");
                                    Console.Write("Enter option: ");
                                    Enter = Console.ReadLine();

                                }

                            }
                            //This condition will check if the recipe that the user wants to scale exists in the array
                            if (ScaleMenu > 0 && ScaleMenu <= recepies.Count)
                            {
                                //The user will be able to select which multiples they would like their recipe to display
                                Console.WriteLine("choose how you want the quantity of the ingredient to be scaled from below options: ");
                                Console.WriteLine("1)Half");
                                Console.WriteLine("2)Double");
                                Console.WriteLine("3)Triple");
                                Console.WriteLine("4)Reset to Original");

                                Console.Write("Enter option: ");
                                Enter = Console.ReadLine();
                                Console.WriteLine();

                                //This is to check if the user inputs a digit
                                while (true)
                                {
                                    if (int.TryParse(Enter, out scale))
                                    {
                                        scale = Convert.ToInt32(Enter);
                                        if (scale > 0)
                                        {
                                            break;
                                        }
                                        else
                                        {
                                            Console.WriteLine("Invalid input! ENTER A DIGIT!!");
                                            Console.Write("Enter option: ");
                                            Enter = Console.ReadLine();
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid input! ENTER A DIGIT!!");
                                        Console.Write("Enter option: ");
                                        Enter = Console.ReadLine();

                                    }
                                }

                                switch (scale)
                                {
                                    case 1: recepies[ScaleMenu - 1].setScaleFactor = 0.5; break;
                                    case 2: recepies[ScaleMenu - 1].setScaleFactor = 2; break;
                                    case 3: recepies[ScaleMenu - 1].setScaleFactor = 3; break;
                                    case 4: recepies[ScaleMenu - 1].setScaleFactor = 1; break;
                                    default: Console.WriteLine("Invalid Option"); break;
                                }

                                ingredients = recepies[ScaleMenu - 1].getIngreients;
                                quantityIngredients = recepies[ScaleMenu - 1].getSizeIngredients;
                                unitMeasures = recepies[ScaleMenu - 1].getUnitMeasures;
                                steps = recepies[ScaleMenu - 1].getSteps;

                                //Displays the recipe
                                Console.WriteLine("-----------------------------------------------------------------------");
                                Console.WriteLine(recepies[ScaleMenu - 1].getRecipe);
                                Console.WriteLine("-----------------------------------------------------------------------");

                                Console.WriteLine("Ingredients: ");
                                for (int j = 0; j < ingredients.Count; j++)
                                {
                                    Console.WriteLine($"- {(quantityIngredients[j] * recepies[ScaleMenu - 1].getScaleFactor)} {unitMeasures[j]} of {ingredients[j]}");
                                }
                                Console.WriteLine("Steps: ");
                                for (int j = 0; j < steps.Count; j++)
                                {
                                    Console.WriteLine($"{(j + 1)}){steps[j]}");
                                }

                            }
                            else
                            {
                                Console.WriteLine("Recipe was not found");
                            }
                            Console.WriteLine("");
                        }
                        else
                        {
                            Console.WriteLine("Enter a recipe before choosing this option");
                        }
                        Console.WriteLine();
                        break;

                    //This case will delete any recpie that the user has inserted
                    case 4:
                        if (!(recepies.Count == 0))
                        {
                            Console.WriteLine("Which recipe would you like to Delete: ");
                            for (int j = 0; j < recepies.Count; j++)
                            {
                                Console.WriteLine($"{(j + 1)}){recepies[j].getRecipe}");
                            }
                            Console.Write("Enter option: ");
                            Enter = Console.ReadLine();

                            //This is to check if the user inputs a digit
                            while (true)
                            {
                                if (int.TryParse(Enter, out DeleteMenu))
                                {
                                    DeleteMenu = Convert.ToInt32(Enter );
                                    if (DeleteMenu > 0)
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid input! ENTER A DIGIT!!");
                                        Console.Write("Enter option: ");
                                        Enter = Console.ReadLine();
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Invalid input! ENTER A DIGIT!!");
                                    Console.Write("Enter option: ");
                                    Enter = Console.ReadLine();

                                }

                            }

                            //This condition will check if the recipe that the user wants to delete exists in the array
                            if (DeleteMenu > 0 && DeleteMenu <= recepies.Count)
                            {
                                recepies.RemoveAt(DeleteMenu - 1);
                                numRecipe--;
                                Console.WriteLine("The recipe has been successfully deleted.");
                            }
                            else
                            {
                                Console.WriteLine("Unable to Delete recipe");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Enter a recipe before choosing this option");
                        }
                        Console.WriteLine();
                        break;

                    //This case will exit the progarm
                    case 5:
                        exit = false;
                        Console.WriteLine("-----------------------------------------------------------------------");
                        Console.WriteLine("Thank You and Come again");
                        Console.WriteLine("-----------------------------------------------------------------------");
                        Console.WriteLine();
                        break;
                    default:
                        Console.WriteLine("Invalid Option");
                        Console.WriteLine();
                        break;

                }
            }
            Console.ReadKey();
        }
    }
}
