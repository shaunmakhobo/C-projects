# POE_Ingedients_Code

#How to open the code#
  1) Get Visual Studio Code open (install if not already).
  2) Launch the newly created folder.
  3) open the folder-related file.
  4) look at the code.

#run the code#
1) Click the green icon on the menu that has the start name next to it.
2) There will be a black console that asks for input from the user.

  
