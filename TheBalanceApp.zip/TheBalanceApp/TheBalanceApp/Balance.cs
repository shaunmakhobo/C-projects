﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheBalanceApp
{
    internal class Balance
    {
        private int limitBalance;

        public int LimitBalance
        {
            get { return limitBalance; }
            set { limitBalance = value; }
        }

        public void checkLimitBalance(int limit)
        {
            if (limit < 0)
            {
               throw new ArgumentOutOfRangeException("limit", limit, "Limit was out of range");
            }
            if (limit > 10)
            {
                throw new ArgumentOutOfRangeException("limit", limit, "Limit was above 10");
            }
            limitBalance = limitBalance + limit;

            Console.WriteLine(limitBalance);
        }
    }
}
