﻿namespace TheBalanceApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Declaration
            int limit;
            int limitBalance;

            Balance balance = new Balance();
            try
            {
                Console.Write("Enter the limit: ");
                limit = int.Parse(Console.ReadLine());

                Console.Write("Enter the limit balance: ");
                limitBalance = int.Parse(Console.ReadLine());

                balance.LimitBalance = limitBalance;

                balance.checkLimitBalance(limit);
            }
            catch (ArgumentOutOfRangeException ex) 
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
