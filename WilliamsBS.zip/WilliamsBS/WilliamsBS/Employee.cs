﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WilliamsBS
{
    internal class Employee
    {
        //Declaration
        private string name;
        private string surname;
        private double hoursWorked;
        private double hoursRate;
        private double bonus;

        public string Name 
        {
            get { return name; }
            set {  name = value; }
        }
        public string Surname
        {
            get { return surname; }
            set { surname = value; }
        }
        public double HoursWorked
        {
            get { return hoursWorked; }
            set { hoursWorked = value; }
        }
        public double HoursRate
        {
            get { return hoursRate; }
            set { hoursRate = value; }
        }
        public double Bonus
        {
            get { return bonus; }
            set { bonus = value; }
        }

        public Employee(string name,
                       string surname,
                       double hoursWorked,
                       double hoursRate)
        {
            this.name = name;
            this.surname = surname;
            this.hoursWorked = hoursWorked;
            this.hoursRate = hoursRate;
        }

        public Employee()
        {
            
        }

        public Employee(string name,
                       string surname,
                       double hoursWorked,
                       double hoursRate,
                       ref double bonus)
        {
            bonus = 1400.00;
            this.name = name;
            this.surname = surname;
            this.hoursWorked = hoursWorked;
            this.hoursRate = hoursRate;
            this.bonus = bonus;
            
        }

        //Calculating salary
        public double CalcSalary(double hoursWorked,
                                 double hoursRate)
        {
            double salary = 0;

            salary = hoursWorked * hoursRate;
          return salary;
        }

        //Calculate salary with bonus
        public double CalcSalary(double hoursWorked,
                                 double hoursRate,
                                 ref double bonus)
        {
            double salary = 0;

            salary = (hoursWorked * hoursRate) + bonus;
            return salary;
        }
    }
}
