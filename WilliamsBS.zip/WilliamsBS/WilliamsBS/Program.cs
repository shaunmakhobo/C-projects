﻿namespace WilliamsBS
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Showing memory using GC 
            Console.WriteLine("Total Memory:"
                          + GC.GetTotalMemory(false));

            //Declarations
            string name = null;
            string surname = null;
            double hoursWOrked = 0;
            double hoursRate = 0;
            double bonus = 0;

            //instances of emplyee class
            Employee salesperson = null;
            Employee supervisor = null;
            Employee employee = new Employee();

            //Displaying the generation
            Console.WriteLine(
   "The generation number of object employee is: "
   + GC.GetGeneration(employee));

            //prompting user
            Console.Write("Enter name: ");
            name = Console.ReadLine();
            Console.Write("Enter surname: ");
            surname = Console.ReadLine();
            Console.Write("Enter hours worked: ");
            hoursWOrked = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter hours rate: ");
            hoursRate = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();

            salesperson = new Employee(name, surname, hoursWOrked, hoursRate);
            supervisor = new Employee(name, surname, hoursWOrked, hoursRate, ref bonus);
           // bonus = supervisor.Bonus;

            //Displaying
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine("Salesperson");
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine($"Names: {salesperson.Name} {salesperson.Surname} \n Hours worked: {salesperson.HoursWorked} \n Hours rate{salesperson.HoursRate} \n Salary: {salesperson.CalcSalary(hoursWOrked, hoursRate)}");
            Console.WriteLine("");

            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine("Supervisor");
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine($"Names: {supervisor.Name} {supervisor.Surname} \n Hours worked: {supervisor.HoursWorked} \n Hours rate{supervisor.HoursRate} \n Salary: {supervisor.CalcSalary(hoursWOrked, hoursRate, ref bonus)}");
            Console.WriteLine("");

            //Displaying the total memory allocated for the managed heap
            GC.Collect();
            Console.WriteLine(
    "The generation number of object salesperson is: "
    + GC.GetGeneration(salesperson));
            Console.WriteLine(
   "The generation number of object supervisor is: "
   + GC.GetGeneration(supervisor));
            Console.WriteLine("Total Memory used:"
                              + GC.GetTotalMemory(true));
            Console.WriteLine("Total memory left:"
                               + GC.GetTotalMemory(false));

            Console.ReadKey();
        }

    }
}
