﻿namespace RC_arrayInput
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Declaration
            double[] prices = new double[4];
            string[] itemName = new string[4];
            try
            {

                //input 
                for (int i = 0; i < prices.Length; i++)
                {
                    Console.Write("Enter item name " + (i+1) + " : " );
                    itemName[i] = Console.ReadLine();
                    Console.Write("Enter price " + (i + 1) + " : R");
                    prices[i] = double.Parse(Console.ReadLine());
                }

                for (int i = 0; i < itemName.Length; i++)
                {
                    Console.WriteLine("--------------------------------------");
                    Console.WriteLine("{0} : {1:c2}", itemName[i], prices[i] );
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            Console.ReadKey();
        }
    }
}
