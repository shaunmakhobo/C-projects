﻿namespace VatCalculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Declaration
            const double Vat = 0.15;
            double vatAmount;
            double amountSpent;
            double totalAmount;

            //Prompt user
            Console.Write("Please Enter Amount spent: R");
            amountSpent = Convert.ToDouble(Console.ReadLine());

            //Calling methods that calculated
            vatAmount = CalcVat(amountSpent, Vat);
            totalAmount = CalcTotal(amountSpent, vatAmount);

            //Display output
            Console.WriteLine("Total vat is = {0:c}", vatAmount);
            Console.WriteLine("Total amount spent is  {0:c} + {1:c} = {2:c}", vatAmount, amountSpent, totalAmount);

            Console.ReadKey();
        }
        public static double CalcVat(double chargedAmount, double Vat)
        {
            //Declare
            
            double amountOfVat;

            //Calculate Vat
            amountOfVat = chargedAmount * Vat;

            return amountOfVat;
        }
       public static double CalcTotal(double moneySpent, double amountOfVat)
        {
          //Declaration
          double totalAmount;

          //calculation
          totalAmount = moneySpent + amountOfVat;

         return totalAmount;
        }
    }
}
