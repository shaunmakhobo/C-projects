﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Xml.Linq;

namespace Registration_St
{
   // using System.Linq;
    internal class Program
    {
        
        static void Main(string[] args)
        {
            double totalCost = 0;
            double newTotal = 0;
            string firstName = "";
            string lastName = "";
            int age = 0;
            string moduleCode;
            int studentNum = 0;
            double moduleCost;
            int response;
            double discount;

            try
            {
                //Setting number of students
                int stSize = 0;
                Console.Write("Enter number of Students: ");
                stSize = Convert.ToInt32(Console.ReadLine());

                //Declaring array for student
                Student[] students = new Student[stSize];
                
               
                
                    
                        for (int i = 0; i < students.Length; i++)
                        {


                            //Taking student information
                            Console.Write("Enter student first name: ");
                            firstName = Console.ReadLine();
                            Console.Write("Enter student last name: ");
                            lastName = Console.ReadLine();
                            Console.Write("Enter student number: ST");
                            studentNum = Convert.ToInt32(Console.ReadLine());
                            Console.Write("Enter student age: ");
                            age = Convert.ToInt32(Console.ReadLine());

                            //setting number of modules
                            int moduleNo = 0;
                            Console.Write("Enter number of modules: ");
                            moduleNo = Convert.ToInt32(Console.ReadLine());

                            Modules[] modules = new Modules[moduleNo];

                            for (int j = 0; j < modules.Length; j++)
                            {


                                Console.Write("Enter name of module: ");
                                string name = Console.ReadLine();
                                Console.Write("Enter cost of module: R");
                                double cost = Convert.ToInt32(Console.ReadLine());

                                modules[j] = new Modules(name, cost);


                            }
                    foreach (var s in modules)
                    {
                        //Calculating student fees
                        totalCost += s.ModuleCost;

                    }
                    // Console.WriteLine($"{firstName} owes {totalCost}");

                    

                    

                    students[i] = new Student(modules, firstName, lastName, studentNum, age);

                    Console.WriteLine("how would you like to pay?");
                    Console.WriteLine("1. cash");
                    Console.WriteLine("2. two parts");
                    Console.WriteLine("3. Other");
                    response = Convert.ToInt32(Console.ReadLine());


                    switch (response)
                    {
                        case 1:
                            discount = totalCost * 0.2;
                            newTotal = totalCost - discount;

                            //Displaying
                            //student[i].FirstName
                            Console.WriteLine("-------------------------------------------------------");
                            Console.WriteLine($"Student number: ST{studentNum}");
                            Console.WriteLine($"Student firstName: {firstName}");
                            Console.WriteLine($"Student lastName: {lastName}");
                            Console.WriteLine($"Student age: {age}");
                            Console.WriteLine($"Student got a discount of 20% from {totalCost}");
                            Console.WriteLine($"Student fee: {newTotal}");
                            Console.WriteLine($"------------------------------------------------------");
                            break;
                        case 2:
                            discount = totalCost * 0.1;
                            newTotal = totalCost - discount;

                            //Displaying
                            Console.WriteLine("-------------------------------------------------------");
                            Console.WriteLine($"Student number: ST{studentNum}");
                            Console.WriteLine($"Student firstName: {firstName}");
                            Console.WriteLine($"Student lastName: {lastName}");
                            Console.WriteLine($"Student age: {age}");
                            Console.WriteLine($"Student got a discount of 10% from {totalCost}");
                            Console.WriteLine($"Student fee: {newTotal}");
                            Console.WriteLine($"------------------------------------------------------");
                            break;
                        case 3:

                            //Displaying
                            Console.WriteLine("-------------------------------------------------------");
                            Console.WriteLine($"Student number: ST{studentNum}");
                            Console.WriteLine($"Student firstName: {firstName}");
                            Console.WriteLine($"Student lastName: {lastName}");
                            Console.WriteLine($"Student age: {age}");
                            Console.WriteLine($"Student fee: {totalCost}");
                            Console.WriteLine($"------------------------------------------------------");
                            break;
                    }
                
                }

            } 
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
       
    }
}
