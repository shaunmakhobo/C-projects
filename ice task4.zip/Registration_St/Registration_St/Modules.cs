﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registration_St
{
    internal class Modules
    {
        private string moduleName;
        private double moduleCost;
        
        public string ModuleName
        {
            get { return moduleName; }
            set { moduleName = value; }
        }
        public double ModuleCost
        {
            get { return moduleCost; }
            set { moduleCost = value; }
        }

       public Modules(string name, double cost)
        {
            this.moduleName = name;
            this.moduleCost = cost;
        }
    }
}
