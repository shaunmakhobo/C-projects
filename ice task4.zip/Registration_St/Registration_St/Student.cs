﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registration_St
{
    internal class Student
    {
        private string firstName;
        private string lastName;
        private int age;
        private int studentNumber;
       private Modules[] modules;

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
        public int Age 
        {
            get { return age; }
            set { age = value; }
        }
        public int StudentNumber
        {
            get { return studentNumber; }
            set { studentNumber = value; }
        }

        public Student(Modules[] modules, string firstName, string lastName, int studentNumber, int age)
        {
            this.modules = modules; 
            this.firstName = firstName;
            this.lastName = lastName;
            this.studentNumber = studentNumber;
            this.age = age;
        }
      
     
    }
}
