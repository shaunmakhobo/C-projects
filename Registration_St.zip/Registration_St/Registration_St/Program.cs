﻿using System.Runtime.CompilerServices;

namespace Registration_St
{
   // using System.Linq;
    internal class Program
    {
        
        static void Main(string[] args)
        {
            double totalCost = 0;

            try
            {
                //Setting number of students
                int stSize = 0;
                Console.Write("Enter number of Students: ");
                stSize = Convert.ToInt32(Console.ReadLine());

                //Declaring array for student
                Student[] students = new Student[stSize];
            

                //Taking student information
                for (int i = 0; i < students.Length; i++)
                {

                    students[i] = new Student();

                    Console.Write("Enter student first name: ");
                    students[i].FirstName = Console.ReadLine();
                    Console.Write("Enter student last name: ");
                    students[i].LastName = Console.ReadLine();
                    Console.Write("Enter student number: ST");
                    students[i].StudentNumber = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter student age: ");
                    students[i].Age = Convert.ToInt32(Console.ReadLine());

                    //setting number of modules
                    int moduleNo = 0;
                    Console.Write("Enter number of modules: ");
                    moduleNo = Convert.ToInt32(Console.ReadLine());

                    Modules[] modules = new Modules[moduleNo];

                    for (int j = 0; j < modules.Length; j++)
                    {
                        modules[j] = new Modules();

                        Console.Write("Enter name of module: ");
                        string name = Console.ReadLine();
                        Console.Write("Enter cost of module: R");
                        double cost = Convert.ToInt32(Console.ReadLine());

                        modules[j].ModuleName = name;
                        modules[j].ModuleCost = cost;

                        foreach (var s in modules)
                        {
                            totalCost += s.ModuleCost;
                        }
                    }
                   
                }
                
            } 
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
       
    }
}
