﻿namespace RC_Shop
{
    internal class Program
    {
       private static void Main(string[] args)
        {
          //Declaration
          item Item = new item();
            double amtDue;
            int noItems;
            //double discount;
           // int itemPrice;

            //Input
            try
            {
                Console.Write("Enter item name: ");
                Item.ItemName = Console.ReadLine();
                Console.Write("Enter item price: ");
                Item.ItemPrice = Convert.ToDouble(Console.ReadLine());
                Console.Write("how many items would you like to buy? ");
                noItems = Convert.ToInt32(Console.ReadLine());

               
                //Calculation
                amtDue = Item.calcAmtDue(noItems);

                //Check for discount
                if (noItems > 10)
                {
                    amtDue = Item.calcDiscount(amtDue);
                    Console.WriteLine("You have a discount of 5%");
                }


                //Output
                Console.WriteLine("Amount Due is {0:c}", amtDue);

            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
