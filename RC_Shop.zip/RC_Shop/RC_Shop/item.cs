﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RC_Shop
{
    internal class item
    {
        //Data members
        private string itemName;
        private double itemPrice;
        private double amtDue;
        private double Discount;

        //properties
        public string ItemName {
            get { return itemName; } 
            set { itemName = value; }
        }
        public double ItemPrice { 
            get { return itemPrice; } 
            set {  itemPrice = value; }
        }

        public double calcAmtDue(int noItems)
        {
            amtDue = itemPrice * noItems;   
            
            return amtDue;
        }
        public double calcDiscount(double amtDue)
        {
            Discount = amtDue - (amtDue * 0.05);
            return Discount;
        }
    }

}
